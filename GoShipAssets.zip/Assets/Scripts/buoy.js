﻿#pragma strict

private var rb : Rigidbody;
public var speed : float;

function Start () {
	rb = GetComponent.<Rigidbody>();
	rb.velocity = new Vector3(0,0,speed);
	
}

function Update () {
	
	rb.velocity = new Vector3(speed,0,0);
}